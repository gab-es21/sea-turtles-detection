# sea-turtles > 2023-10-22 1:34am
https://universe.roboflow.com/gabriel-esteves-dy2cw/sea-turtles-yia2e

Provided by a Roboflow user
License: CC BY 4.0

